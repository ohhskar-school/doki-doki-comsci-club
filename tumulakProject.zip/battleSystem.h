#ifndef BATTLESYSTEM_H
#define BATTLESYSTEM_H
#include "gameInfo.h"

int bossBattle(int bossSelection, gameInfo _battleInfo);
#endif