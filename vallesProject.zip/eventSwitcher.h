#ifndef EVENTSWITCHER_H
#define EVENTSWITCHER_H
#include "gameInfo.h"

gameInfo eventSwitcher(gameInfo);

#endif